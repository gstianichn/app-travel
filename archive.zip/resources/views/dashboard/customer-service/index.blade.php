<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Customer Service</title>
</head>
<body>

    <h1>Dashboard Customer Service</h1>

    <p>Selamat datang di dashboard Customer Service.</p>

</body>
</html>