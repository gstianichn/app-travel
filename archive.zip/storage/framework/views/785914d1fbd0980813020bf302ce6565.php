<header class="flex h-16 items-center justify-between border-b border-slate-200 bg-white px-6">

    
    <div>
        <h1 class="text-lg font-semibold text-slate-800">
            <?php echo $__env->yieldContent('title', 'Dashboard'); ?>
        </h1>
    </div>

    
    <?php if(auth()->guard()->check()): ?>
        <div class="flex items-center gap-3">

            <div class="hidden text-right sm:block">
                <p class="text-sm font-semibold text-slate-800">
                    <?php echo e(auth()->user()->name); ?>

                </p>

                <p class="text-xs text-slate-500">
                    <?php echo e(str_replace('_', ' ', ucfirst(auth()->user()->role))); ?>

                </p>
            </div>

            <div class="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 font-semibold text-blue-600">
                <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

            </div>

        </div>
    <?php endif; ?>

</header><?php /**PATH D:\laravel\app-travel\resources\views\components\dashboard\topbar.blade.php ENDPATH**/ ?>