<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Driver</title>
</head>
<body>

    <h1>Dashboard Driver</h1>

    <p>Selamat datang di dashboard driver.</p>

</body>
</html><?php /**PATH D:\laravel\app-travel\resources\views/dashboard/driver/index.blade.php ENDPATH**/ ?>