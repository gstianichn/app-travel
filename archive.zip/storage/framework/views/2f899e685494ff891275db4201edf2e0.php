

<?php $__env->startSection('title', 'Cari Travel - TravelKu'); ?>

<?php $__env->startSection('content'); ?>

<section class="search-page">

    <div class="container">

        <div class="search-page-header">

            <span class="section-label">
                Cari Perjalanan
            </span>

            <h1>
                Temukan Jadwal Travel
            </h1>

            <p>
                Pilih rute dan tanggal perjalanan
                yang Anda inginkan.
            </p>

        </div>


        

        <div class="search-page-card">

            <form
                action="<?php echo e(route('search')); ?>"
                method="GET"
            >

                <div class="search-form-grid">

                    <div class="form-group">

                        <label for="origin">
                            Dari
                        </label>

                        <select
                            name="origin"
                            id="origin"
                            class="form-control"
                            required
                        >
                            <option value="">
                                Pilih kota asal
                            </option>

                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($location->id); ?>"
                                    <?php if(
                                        request('origin') == $location->id
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($location->name); ?>

                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </div>


                    <div class="form-group">

                        <label for="destination">
                            Ke
                        </label>

                        <select
                            name="destination"
                            id="destination"
                            class="form-control"
                            required
                        >
                            <option value="">
                                Pilih kota tujuan
                            </option>

                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($location->id); ?>"
                                    <?php if(
                                        request('destination') == $location->id
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($location->name); ?>

                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </div>


                    <div class="form-group">

                        <label for="departure_date">
                            Tanggal
                        </label>

                        <input
                            type="date"
                            name="departure_date"
                            id="departure_date"
                            class="form-control"
                            value="<?php echo e(request('departure_date')); ?>"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label for="passengers">
                            Penumpang
                        </label>

                        <select
                            name="passengers"
                            id="passengers"
                            class="form-control"
                            required
                        >

                            <?php for($i = 1; $i <= 10; $i++): ?>

                                <option
                                    value="<?php echo e($i); ?>"
                                    <?php if(
                                        request('passengers', 1) == $i
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($i); ?> Penumpang
                                </option>

                            <?php endfor; ?>

                        </select>

                    </div>

                </div>


                <button
                    type="submit"
                    class="btn btn-primary search-button"
                >
                    Cari Travel
                </button>

            </form>

        </div>


        

        <?php if($errors->any()): ?>

            <div class="alert alert-error">

                <strong>
                    Pencarian tidak dapat dilakukan.
                </strong>

                <ul>

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li>
                            <?php echo e($error); ?>

                        </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>

            </div>

        <?php endif; ?>


        

        <?php if($searchPerformed): ?>

            <div class="search-result">

                <div class="result-header">

                    <div>

                        <span class="section-label">
                            Hasil Pencarian
                        </span>

                        <h2>
                            Jadwal Tersedia
                        </h2>

                    </div>

                    <span class="result-count">
                        <?php echo e($schedules->count()); ?> perjalanan
                    </span>

                </div>


                <?php if($schedules->count() > 0): ?>

                    <div class="schedule-list">

                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <article class="schedule-card">

                                <div class="schedule-route">

                                    <span>
                                        <?php echo e($schedule->route->origin->name); ?>

                                    </span>

                                    <strong>
                                        →
                                    </strong>

                                    <span>
                                        <?php echo e($schedule->route->destination->name); ?>

                                    </span>

                                </div>


                                <div class="schedule-info">

                                    <div>

                                        <small>
                                            Keberangkatan
                                        </small>

                                        <strong>
                                            <?php echo e($schedule->departure_time); ?>

                                        </strong>

                                    </div>


                                    <div>

                                        <small>
                                            Durasi
                                        </small>

                                        <strong>
                                            <?php echo e($schedule->route->duration); ?>

                                        </strong>

                                    </div>


                                    <div>

                                        <small>
                                            Harga
                                        </small>

                                        <strong>
                                            Rp <?php echo e(number_format(
                                                $schedule->route->price,
                                                0,
                                                ',',
                                                '.'
                                            )); ?>

                                        </strong>

                                    </div>


                                    <div>

                                        <small>
                                            Kursi tersedia
                                        </small>

                                        <strong>
                                            <?php echo e($schedule->available_seats); ?>

                                        </strong>

                                    </div>

                                </div>


                                <div class="schedule-action">

                                    <button
                                        type="button"
                                        class="btn btn-primary"
                                    >
                                        Pilih Travel
                                    </button>

                                </div>

                            </article>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php else: ?>

                    <div class="empty-result">

                        <h3>
                            Jadwal tidak ditemukan
                        </h3>

                        <p>
                            Belum ada perjalanan yang tersedia
                            sesuai dengan pencarian Anda.
                        </p>

                    </div>

                <?php endif; ?>

            </div>

        <?php endif; ?>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\app-travel\resources\views\search\index.blade.php ENDPATH**/ ?>