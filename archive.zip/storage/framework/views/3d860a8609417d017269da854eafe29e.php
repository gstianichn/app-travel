<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Login | Travel</title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.js'
    ]); ?>

    <style>
        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            width: 100%;
            min-height: 100%;
        }

        body {
            font-family:
                Inter,
                ui-sans-serif,
                system-ui,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            background: #f7f9f8;
            color: #17221d;
        }

        .login-page {
            min-height: 100vh;
            display: grid;
            grid-template-columns: 1fr 1fr;
        }

        /* =====================================================
           LEFT
        ===================================================== */

        .login-brand {
            position: relative;
            min-height: 100vh;
            overflow: hidden;

            background:
                linear-gradient(
                    145deg,
                    #087f52 0%,
                    #0b8b5c 45%,
                    #076f49 100%
                );

            color: white;
        }

        .brand-content {
            position: relative;
            z-index: 2;

            min-height: 100vh;

            display: flex;
            flex-direction: column;
            justify-content: space-between;

            padding: 48px 56px;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .brand-logo-icon {
            width: 48px;
            height: 48px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 14px;

            background: rgba(255, 255, 255, 0.14);

            font-size: 23px;

            box-shadow:
                0 10px 30px rgba(0, 0, 0, 0.08);
        }

        .brand-logo-title {
            margin: 0;

            font-size: 20px;
            font-weight: 700;

            letter-spacing: -0.02em;
        }

        .brand-logo-subtitle {
            margin: 3px 0 0;

            font-size: 12px;

            color: rgba(255, 255, 255, 0.7);
        }

        .brand-hero {
            max-width: 580px;
        }

        .brand-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;

            padding: 8px 14px;

            margin-bottom: 22px;

            border: 1px solid rgba(255, 255, 255, 0.16);
            border-radius: 999px;

            background: rgba(255, 255, 255, 0.09);

            font-size: 12px;
            font-weight: 600;

            color: rgba(255, 255, 255, 0.9);
        }

        .brand-badge-dot {
            width: 7px;
            height: 7px;

            border-radius: 50%;

            background: #ffffff;
        }

        .brand-title {
            margin: 0;

            font-size: clamp(42px, 4vw, 62px);
            line-height: 1.08;

            font-weight: 800;

            letter-spacing: -0.045em;
        }

        .brand-title-muted {
            display: block;

            color: rgba(255, 255, 255, 0.58);
        }

        .brand-description {
            max-width: 500px;

            margin: 24px 0 0;

            font-size: 16px;
            line-height: 1.7;

            color: rgba(255, 255, 255, 0.76);
        }

        .brand-features {
            display: grid;
            grid-template-columns: repeat(3, 1fr);

            gap: 12px;

            max-width: 540px;

            margin-top: 34px;
        }

        .brand-feature {
            padding: 16px;

            border: 1px solid rgba(255, 255, 255, 0.12);

            border-radius: 16px;

            background: rgba(255, 255, 255, 0.09);

            backdrop-filter: blur(10px);
        }

        .brand-feature-icon {
            margin-bottom: 10px;

            font-size: 21px;
        }

        .brand-feature-title {
            margin: 0;

            font-size: 14px;
            font-weight: 700;
        }

        .brand-feature-text {
            margin: 4px 0 0;

            font-size: 11px;

            line-height: 1.5;

            color: rgba(255, 255, 255, 0.62);
        }

        .brand-footer {
            display: flex;
            justify-content: space-between;

            font-size: 11px;

            color: rgba(255, 255, 255, 0.5);
        }

        /* Decorative circles */

        .circle {
            position: absolute;

            border-radius: 50%;

            background: rgba(255, 255, 255, 0.07);
        }

        .circle-one {
            width: 330px;
            height: 330px;

            top: -150px;
            left: -130px;
        }

        .circle-two {
            width: 420px;
            height: 420px;

            right: -200px;
            bottom: -190px;
        }

        .circle-three {
            width: 110px;
            height: 110px;

            right: 100px;
            top: 36%;
        }

        .circle-four {
            width: 70px;
            height: 70px;

            left: 38%;
            bottom: 15%;
        }

        /* =====================================================
           RIGHT
        ===================================================== */

        .login-panel {
            min-height: 100vh;

            display: flex;
            align-items: center;
            justify-content: center;

            padding: 48px;
        }

        .login-wrapper {
            width: 100%;
            max-width: 440px;
        }

        .mobile-logo {
            display: none;
        }

        .login-heading {
            margin-bottom: 28px;
        }

        .login-label {
            display: block;

            margin-bottom: 8px;

            font-size: 12px;
            font-weight: 700;

            letter-spacing: 0.18em;
            text-transform: uppercase;

            color: #078355;
        }

        .login-title {
            margin: 0;

            font-size: 36px;
            line-height: 1.15;

            font-weight: 800;

            letter-spacing: -0.04em;

            color: #17221d;
        }

        .login-description {
            margin: 10px 0 0;

            font-size: 14px;
            line-height: 1.6;

            color: #718078;
        }

        .login-card {
            padding: 32px;

            border: 1px solid #e2e8e4;

            border-radius: 24px;

            background: #ffffff;

            box-shadow:
                0 20px 60px rgba(20, 50, 38, 0.08);
        }

        .error-box {
            margin-bottom: 22px;

            padding: 14px 16px;

            border: 1px solid #fecaca;

            border-radius: 14px;

            background: #fef2f2;

            color: #dc2626;

            font-size: 13px;

            line-height: 1.5;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;

            margin-bottom: 8px;

            font-size: 13px;
            font-weight: 700;

            color: #26342d;
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;

            left: 15px;
            top: 50%;

            transform: translateY(-50%);

            width: 19px;
            height: 19px;

            color: #8a9991;

            pointer-events: none;
        }

        .form-input {
            width: 100%;
            height: 50px;

            padding: 0 46px;

            border: 1px solid #dce4df;

            border-radius: 13px;

            outline: none;

            background: #f9fbfa;

            color: #17221d;

            font-size: 14px;

            transition:
                border-color 0.2s ease,
                box-shadow 0.2s ease,
                background 0.2s ease;
        }

        .form-input::placeholder {
            color: #a5afa9;
        }

        .form-input:hover {
            border-color: #b8c8bf;
        }

        .form-input:focus {
            border-color: #078355;

            background: #ffffff;

            box-shadow:
                0 0 0 4px rgba(7, 131, 85, 0.09);
        }

        .password-toggle {
            position: absolute;

            right: 14px;
            top: 50%;

            transform: translateY(-50%);

            display: flex;
            align-items: center;
            justify-content: center;

            width: 30px;
            height: 30px;

            border: 0;

            background: transparent;

            color: #8a9991;

            cursor: pointer;
        }

        .password-toggle:hover {
            color: #078355;
        }

        .remember-row {
            display: flex;
            align-items: center;

            margin-bottom: 22px;
        }

        .remember-label {
            display: flex;
            align-items: center;

            gap: 9px;

            font-size: 13px;

            color: #718078;

            cursor: pointer;
        }

        .remember-label input {
            width: 16px;
            height: 16px;

            accent-color: #078355;
        }

        .login-button {
            width: 100%;
            height: 50px;

            display: flex;
            align-items: center;
            justify-content: center;

            gap: 9px;

            border: 0;
            border-radius: 13px;

            background: #078355;

            color: #ffffff;

            font-size: 14px;
            font-weight: 700;

            cursor: pointer;

            box-shadow:
                0 10px 22px rgba(7, 131, 85, 0.2);

            transition:
                transform 0.2s ease,
                background 0.2s ease,
                box-shadow 0.2s ease;
        }

        .login-button:hover {
            transform: translateY(-1px);

            background: #066d47;

            box-shadow:
                0 14px 28px rgba(7, 131, 85, 0.25);
        }

        .login-button:active {
            transform: translateY(0);
        }

        .divider {
            display: flex;
            align-items: center;

            gap: 14px;

            margin: 24px 0;
        }

        .divider-line {
            flex: 1;

            height: 1px;

            background: #e6ebe8;
        }

        .divider-text {
            font-size: 10px;
            font-weight: 600;

            letter-spacing: 0.08em;

            color: #98a49e;
        }

        .register-button {
            width: 100%;
            height: 50px;

            display: flex;
            align-items: center;
            justify-content: center;

            border: 1px solid #dce4df;

            border-radius: 13px;

            background: #ffffff;

            color: #26342d;

            text-decoration: none;

            font-size: 14px;
            font-weight: 700;

            transition:
                border-color 0.2s ease,
                background 0.2s ease,
                color 0.2s ease;
        }

        .register-button:hover {
            border-color: #078355;

            background: #f2faf6;

            color: #078355;
        }

        .security-info {
            display: flex;
            align-items: center;
            justify-content: center;

            gap: 7px;

            margin-top: 20px;

            font-size: 11px;

            color: #89958f;
        }

        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 1024px) {

            .brand-content {
                padding: 40px;
            }

            .login-panel {
                padding: 32px;
            }

            .brand-title {
                font-size: 46px;
            }

        }

        @media (max-width: 768px) {

            .login-page {
                display: block;
            }

            .login-brand {
                display: none;
            }

            .login-panel {
                min-height: 100vh;

                padding: 32px 20px;
            }

            .login-wrapper {
                max-width: 460px;
            }

            .mobile-logo {
                display: flex;
                align-items: center;
                justify-content: center;

                gap: 10px;

                margin-bottom: 32px;
            }

            .mobile-logo-icon {
                width: 44px;
                height: 44px;

                display: flex;
                align-items: center;
                justify-content: center;

                border-radius: 13px;

                background: #078355;

                font-size: 21px;
            }

            .mobile-logo-title {
                font-size: 20px;
                font-weight: 800;

                color: #078355;
            }

            .login-title {
                font-size: 32px;
            }

            .login-card {
                padding: 24px;
            }

        }

        @media (max-width: 480px) {

            .login-panel {
                padding: 24px 16px;
            }

            .login-card {
                padding: 20px;

                border-radius: 20px;
            }

            .login-title {
                font-size: 28px;
            }

        }
    </style>
</head>


<body>

    <main class="login-page">

        

        <section class="login-brand">

            <div class="circle circle-one"></div>
            <div class="circle circle-two"></div>
            <div class="circle circle-three"></div>
            <div class="circle circle-four"></div>


            <div class="brand-content">

                
                <div class="brand-logo">

                    <div class="brand-logo-icon">
                        🌿
                    </div>

                    <div>
                        <h2 class="brand-logo-title">
                            Travel
                        </h2>

                        <p class="brand-logo-subtitle">
                            Your Journey, Our Service
                        </p>
                    </div>

                </div>


                
                <div class="brand-hero">

                    <div class="brand-badge">

                        <span class="brand-badge-dot"></span>

                        Platform Travel Terpercaya

                    </div>


                    <h1 class="brand-title">

                        Perjalanan nyaman,

                        <span class="brand-title-muted">
                            dimulai dari sini.
                        </span>

                    </h1>


                    <p class="brand-description">
                        Temukan perjalanan yang sesuai dengan kebutuhan Anda.
                        Pesan dengan mudah dan nikmati pengalaman perjalanan
                        yang aman dan nyaman bersama Travel.
                    </p>


                    <div class="brand-features">

                        <div class="brand-feature">

                            <div class="brand-feature-icon">
                                🚌
                            </div>

                            <p class="brand-feature-title">
                                Mudah
                            </p>

                            <p class="brand-feature-text">
                                Pemesanan praktis
                            </p>

                        </div>


                        <div class="brand-feature">

                            <div class="brand-feature-icon">
                                🔒
                            </div>

                            <p class="brand-feature-title">
                                Aman
                            </p>

                            <p class="brand-feature-text">
                                Data terlindungi
                            </p>

                        </div>


                        <div class="brand-feature">

                            <div class="brand-feature-icon">
                                ✨
                            </div>

                            <p class="brand-feature-title">
                                Nyaman
                            </p>

                            <p class="brand-feature-text">
                                Layanan terbaik
                            </p>

                        </div>

                    </div>

                </div>


                
                <div class="brand-footer">

                    <span>
                        © <?php echo e(date('Y')); ?> Travel
                    </span>

                    <span>
                        Semua hak dilindungi
                    </span>

                </div>

            </div>

        </section>


        

        <section class="login-panel">

            <div class="login-wrapper">

                
                <div class="mobile-logo">

                    <div class="mobile-logo-icon">
                        🌿
                    </div>

                    <div class="mobile-logo-title">
                        Travel
                    </div>

                </div>


                
                <div class="login-heading">

                    <span class="login-label">
                        Login
                    </span>

                    <h1 class="login-title">
                        Selamat Datang 👋
                    </h1>

                    <p class="login-description">
                        Masuk ke akun Anda untuk melanjutkan perjalanan.
                    </p>

                </div>


                
                <div class="login-card">

                    
                    <?php if($errors->any()): ?>

                        <div class="error-box">

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div>
                                    <?php echo e($error); ?>

                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    <?php endif; ?>


                    
                    <form
                        method="POST"
                        action="<?php echo e(route('login.store')); ?>"
                    >

                        <?php echo csrf_field(); ?>


                        
                        <div class="form-group">

                            <label
                                for="email"
                                class="form-label"
                            >
                                Email
                            </label>

                            <div class="input-wrapper">

                                <svg
                                    class="input-icon"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                    stroke-width="1.8"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        d="M3 8l9 6 9-6"
                                    />

                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        d="M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                                    />
                                </svg>


                                <input
                                    id="email"
                                    type="email"
                                    name="email"
                                    value="<?php echo e(old('email')); ?>"
                                    required
                                    autofocus
                                    autocomplete="email"
                                    placeholder="nama@email.com"
                                    class="form-input"
                                >

                            </div>

                        </div>


                        
                        <div class="form-group">

                            <label
                                for="password"
                                class="form-label"
                            >
                                Password
                            </label>

                            <div class="input-wrapper">

                                <svg
                                    class="input-icon"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                    stroke-width="1.8"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        d="M16 11V8a4 4 0 10-8 0v3"
                                    />

                                    <rect
                                        x="4"
                                        y="11"
                                        width="16"
                                        height="10"
                                        rx="2"
                                    />
                                </svg>


                                <input
                                    id="password"
                                    type="password"
                                    name="password"
                                    required
                                    autocomplete="current-password"
                                    placeholder="Masukkan password"
                                    class="form-input"
                                >


                                <button
                                    type="button"
                                    id="togglePassword"
                                    class="password-toggle"
                                    aria-label="Tampilkan password"
                                >

                                    <svg
                                        id="eyeIcon"
                                        xmlns="http://www.w3.org/2000/svg"
                                        fill="none"
                                        viewBox="0 0 24 24"
                                        stroke="currentColor"
                                        stroke-width="1.8"
                                        width="20"
                                        height="20"
                                    >

                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 9.542 7-1.274 4.057-5.065 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                                        />

                                        <circle
                                            cx="12"
                                            cy="12"
                                            r="3"
                                        />

                                    </svg>

                                </button>

                            </div>

                        </div>


                        
                        <div class="remember-row">

                            <label class="remember-label">

                                <input
                                    type="checkbox"
                                    name="remember"
                                >

                                <span>
                                    Ingat saya
                                </span>

                            </label>

                        </div>


                        
                        <button
                            type="submit"
                            class="login-button"
                        >

                            <span>
                                Masuk ke Akun
                            </span>

                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="17"
                                height="17"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                stroke-width="2"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M13 7l5 5m0 0l-5 5m5-5H6"
                                />
                            </svg>

                        </button>

                    </form>


                    
                    <div class="divider">

                        <div class="divider-line"></div>

                        <span class="divider-text">
                            AKUN BARU?
                        </span>

                        <div class="divider-line"></div>

                    </div>


                    
                    <a
                        href="<?php echo e(route('register')); ?>"
                        class="register-button"
                    >
                        Buat Akun Baru
                    </a>

                </div>


                
                <div class="security-info">

                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="15"
                        height="15"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        stroke-width="1.8"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M12 3l7 4v5c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V7l7-4z"
                        />

                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M9 12l2 2 4-4"
                        />

                    </svg>

                    <span>
                        Login aman dan data Anda terlindungi
                    </span>

                </div>

            </div>

        </section>

    </main>


    

    <script>
        document.addEventListener('DOMContentLoaded', function () {

            const button = document.getElementById('togglePassword');
            const password = document.getElementById('password');
            const icon = document.getElementById('eyeIcon');

            if (!button || !password || !icon) {
                return;
            }

            button.addEventListener('click', function () {

                const hidden = password.type === 'password';

                password.type = hidden ? 'text' : 'password';

                button.setAttribute(
                    'aria-label',
                    hidden
                        ? 'Sembunyikan password'
                        : 'Tampilkan password'
                );

                if (hidden) {

                    icon.innerHTML = `
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M3.98 8.223A10.477 10.477 0 001.458 12C2.732 16.057 6.523 19 11 19c1.61 0 3.13-.386 4.46-1.07"
                        />

                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M6.228 6.228A10.45 10.45 0 0111 5c4.477 0 8.268 2.943 9.542 7a10.47 10.47 0 01-2.328 4.332"
                        />

                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M6.228 6.228L3 3m3.228 3.228l3.07 3.07m0 0a3 3 0 104.243 4.243M9.298 9.298l4.243 4.243M21 21l-4.5-4.5"
                        />
                    `;

                } else {

                    icon.innerHTML = `
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 9.542 7-1.274 4.057-5.065 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                        />

                        <circle
                            cx="12"
                            cy="12"
                            r="3"
                        />
                    `;

                }

            });

        });
    </script>

</body>

</html><?php /**PATH D:\laravel\app-travel\resources\views/auth/login.blade.php ENDPATH**/ ?>