<h1>Halaman Staff Admin</h1>
<p>Ini adalah dashboard staff admin</p><?php /**PATH D:\laravel\app-travel\resources\views/dashboard/admin-biasa/index.blade.php ENDPATH**/ ?>