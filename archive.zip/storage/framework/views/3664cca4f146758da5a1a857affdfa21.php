<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Daftar - Travel</title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.js'
    ]); ?>
</head>

<body class="min-h-screen bg-page text-ink">

<div class="flex min-h-screen items-center justify-center px-4 py-10">

    <div class="w-full max-w-md">

        <div class="mb-8 text-center">

            <div class="mb-3 text-3xl font-bold text-brand">
                🌿 Travel
            </div>

            <h1 class="text-2xl font-bold text-ink">
                Buat Akun
            </h1>

            <p class="mt-2 text-brand-support">
                Daftar untuk mulai memesan perjalanan.
            </p>

        </div>

        <div class="rounded-2xl border border-border bg-surface p-6 shadow-sm">

            <?php if($errors->any()): ?>

                <div class="mb-5 rounded-lg bg-red-50 p-4 text-sm text-red-600">

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            <?php endif; ?>

            <form
                method="POST"
                action="<?php echo e(route('register.store')); ?>"
                class="space-y-5"
            >

                <?php echo csrf_field(); ?>

                <div>

                    <label class="mb-2 block text-sm font-medium">
                        Nama Lengkap
                    </label>

                    <input
                        type="text"
                        name="name"
                        value="<?php echo e(old('name')); ?>"
                        required
                        class="w-full rounded-xl border border-border px-4 py-3 outline-none placeholder:text-placeholder focus:border-brand focus:ring-2 focus:ring-brand/20"
                    >

                </div>

                <div>

                    <label class="mb-2 block text-sm font-medium">
                        Email
                    </label>

                    <input
                        type="email"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        required
                        class="w-full rounded-xl border border-border px-4 py-3 outline-none placeholder:text-placeholder focus:border-brand focus:ring-2 focus:ring-brand/20"
                    >

                </div>

                <div>

                    <label class="mb-2 block text-sm font-medium">
                        Nomor Telepon
                    </label>

                    <input
                        type="text"
                        name="phone"
                        value="<?php echo e(old('phone')); ?>"
                        class="w-full rounded-xl border border-border px-4 py-3 outline-none placeholder:text-placeholder focus:border-brand focus:ring-2 focus:ring-brand/20"
                    >

                </div>

                <div>

                    <label class="mb-2 block text-sm font-medium">
                        Password
                    </label>

                    <input
                        type="password"
                        name="password"
                        required
                        class="w-full rounded-xl border border-border px-4 py-3 outline-none placeholder:text-placeholder focus:border-brand focus:ring-2 focus:ring-brand/20"
                    >

                </div>

                <div>

                    <label class="mb-2 block text-sm font-medium">
                        Konfirmasi Password
                    </label>

                    <input
                        type="password"
                        name="password_confirmation"
                        required
                        class="w-full rounded-xl border border-border px-4 py-3 outline-none placeholder:text-placeholder focus:border-brand focus:ring-2 focus:ring-brand/20"
                    >

                </div>

                <button
                    type="submit"
                    class="w-full rounded-xl bg-brand px-4 py-3 font-semibold text-surface hover:bg-brand-dark"
                >
                    Daftar
                </button>

            </form>

            <p class="mt-6 text-center text-sm text-brand-support">

                Sudah punya akun?

                <a
                    href="<?php echo e(route('login')); ?>"
                    class="font-semibold text-brand"
                >
                    Login
                </a>

            </p>

        </div>

    </div>

</div>

</body>

</html><?php /**PATH D:\laravel\app-travel\resources\views\auth\register.blade.php ENDPATH**/ ?>