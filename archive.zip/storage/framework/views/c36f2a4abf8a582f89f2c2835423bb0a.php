<nav class="navbar">
    <div class="container navbar-content">

        <a href="<?php echo e(url('/')); ?>" class="navbar-brand">
            TravelKu
        </a>

        <div class="navbar-menu">
            <a href="<?php echo e(url('/')); ?>" class="<?php echo e(request()->routeIs('home') ? 'navbar-link-active' : ''); ?>">Beranda</a>
            <a href="<?php echo e(url('/search')); ?>" class="<?php echo e(request()->routeIs('search') ? 'navbar-link-active' : ''); ?>">Cari Travel</a>
        </div>

        <div class="navbar-actions">
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline">
                    Masuk
                </a>

                <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">
                    Daftar
                </a>
            <?php else: ?>
                <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-primary">
                    Dashboard
                </a>
            <?php endif; ?>
        </div>

    </div>
</nav><?php /**PATH D:\laravel\app-travel\resources\views/components/navbar.blade.php ENDPATH**/ ?>