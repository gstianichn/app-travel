

<?php $__env->startSection('title', 'Dashboard Admin Utama'); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="mb-6">
        <h2 class="text-2xl font-bold text-slate-800">
            Selamat Datang, <?php echo e(auth()->user()->name); ?>

        </h2>

        <p class="mt-1 text-sm text-slate-500">
            Kelola seluruh aktivitas operasional travel melalui dashboard ini.
        </p>
    </div>


    
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">

        
        <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-500">
                        Total User
                    </p>

                    <p class="mt-2 text-2xl font-bold text-slate-800">
                        0
                    </p>
                </div>

                <div class="flex h-11 w-11 items-center justify-center rounded-lg bg-blue-100 text-blue-600">
                    U
                </div>
            </div>
        </div>


        
        <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-500">
                        Total Driver
                    </p>

                    <p class="mt-2 text-2xl font-bold text-slate-800">
                        0
                    </p>
                </div>

                <div class="flex h-11 w-11 items-center justify-center rounded-lg bg-green-100 text-green-600">
                    D
                </div>
            </div>
        </div>


        
        <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-500">
                        Kendaraan
                    </p>

                    <p class="mt-2 text-2xl font-bold text-slate-800">
                        0
                    </p>
                </div>

                <div class="flex h-11 w-11 items-center justify-center rounded-lg bg-orange-100 text-orange-600">
                    K
                </div>
            </div>
        </div>


        
        <div class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-500">
                        Total Booking
                    </p>

                    <p class="mt-2 text-2xl font-bold text-slate-800">
                        0
                    </p>
                </div>

                <div class="flex h-11 w-11 items-center justify-center rounded-lg bg-purple-100 text-purple-600">
                    B
                </div>
            </div>
        </div>

    </div>


    
    <div class="mt-6">

        <h3 class="mb-4 text-lg font-semibold text-slate-800">
            Menu Cepat
        </h3>

        <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">

            <a
                href="<?php echo e(url('/dashboard/admin/users')); ?>"
                class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:border-blue-300 hover:shadow-md"
            >
                <h4 class="font-semibold text-slate-800">
                    Kelola User
                </h4>

                <p class="mt-1 text-sm text-slate-500">
                    Kelola akun pengguna sistem.
                </p>
            </a>


            <a
                href="<?php echo e(url('/dashboard/admin/drivers')); ?>"
                class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:border-blue-300 hover:shadow-md"
            >
                <h4 class="font-semibold text-slate-800">
                    Kelola Driver
                </h4>

                <p class="mt-1 text-sm text-slate-500">
                    Kelola data driver travel.
                </p>
            </a>


            <a
                href="<?php echo e(url('/dashboard/admin/vehicles')); ?>"
                class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:border-blue-300 hover:shadow-md"
            >
                <h4 class="font-semibold text-slate-800">
                    Kendaraan
                </h4>

                <p class="mt-1 text-sm text-slate-500">
                    Kelola armada kendaraan.
                </p>
            </a>


            <a
                href="<?php echo e(url('/dashboard/admin/schedules')); ?>"
                class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:border-blue-300 hover:shadow-md"
            >
                <h4 class="font-semibold text-slate-800">
                    Jadwal Travel
                </h4>

                <p class="mt-1 text-sm text-slate-500">
                    Kelola jadwal keberangkatan.
                </p>
            </a>

        </div>

    </div>


    
    <div class="mt-6 rounded-xl border border-blue-100 bg-blue-50 p-5">

        <h3 class="font-semibold text-blue-800">
            Informasi
        </h3>

        <p class="mt-1 text-sm text-blue-700">
            Dashboard Admin Utama digunakan untuk mengelola
            seluruh data dan aktivitas aplikasi travel.
        </p>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\app-travel\resources\views\dashboard\admin\index.blade.php ENDPATH**/ ?>