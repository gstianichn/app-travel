<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?php echo $__env->yieldContent('title', 'Dashboard'); ?> - Travel
    </title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.js'
    ]); ?>
</head>

<body class="min-h-screen bg-slate-100 text-slate-800">

    <div class="flex min-h-screen">

        
        <?php echo $__env->make('components.dashboard.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="flex min-w-0 flex-1 flex-col">

            
            <?php echo $__env->make('components.dashboard.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <main class="flex-1 p-6">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

        </div>

    </div>

</body>

</html><?php /**PATH D:\laravel\app-travel\resources\views\layouts\dashboard.blade.php ENDPATH**/ ?>